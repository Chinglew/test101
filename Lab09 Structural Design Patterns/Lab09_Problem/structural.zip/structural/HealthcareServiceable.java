// Please DO NOT MODIFY THIS FILE
package edu.parinya.softarchdesign.structural;

public interface HealthcareServiceable {
    void service();
    double getPrice();
}
